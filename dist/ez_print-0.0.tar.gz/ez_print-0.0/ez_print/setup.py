from setuptools import setup

setup(name='ez_print',
      version='0.0',
      description='',
      packages=['ez_print'],
      author_email='anthonywaghorn869@gmail.com',
      zip_safe=False)